#!/bin/bash

azure/create-vm-endpoint.sh $1 rm-web-ui 8088 8088
