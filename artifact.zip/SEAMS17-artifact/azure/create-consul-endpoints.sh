#!/bin/bash

azure/create-vm-endpoint.sh $1 consul 8500 8500
