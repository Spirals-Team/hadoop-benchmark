#!/bin/bash

azure/create-vm-endpoint.sh $1 nm-web-ui 8042 8042
